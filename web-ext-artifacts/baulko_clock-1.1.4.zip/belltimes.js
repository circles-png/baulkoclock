var belltimes = {
    Monday: {
        period: [
            "Period 1 in:",
            "Period 2 in:",
            "Assembly in:",
            "Recess in:",
            "Period 3 in:",
            "Period 4 in:",
            "Break in:",
            "Period 5 in:",
            "Period 6 in:",
            "Lunch 1 in:",
            "Lunch 2 in:",
            "Period 7 in:",
            "Period 8 in:",
            "End in:"
        ],
        times: [
            518,
            557,
            594,
            619,
            639,
            676,
            713,
            718,
            755,
            792,
            812,
            832,
            869,
            906
        ]
    },
    Tuesday: {
        period: [
            "Period 1 in:",
            "Period 2 in:",
            "Recess in:",
            "Period 3 in:",
            "Period 4 in:",
            "Break in:",
            "Period 5 in:",
            "Period 6 in:",
            "Lunch 1 in:",
            "Lunch 2 in:",
            "Period 7 in:",
            "Period 8 in:",
            "End in:"
        ],
        times: [
            518,
            561,
            601,
            621,
            661,
            701,
            706,
            746,
            786,
            806,
            826,
            866,
            906
        ]
    },
    Wednesday: {
        period: [
            "Period 1 in:",
            "Period 2 in:",
            "Recess in:",
            "Period 3 in:",
            "Period 4 in:",
            "Period 5 in:",
            "Lunch 1 in:",
            "Lunch 2 in:",
            "Period 6 in:",
            "Period 7 in:",
            "Period 8 in:",
            "End in:"
        ],
        times: [
            518,
            558,
            596,
            611,
            649,
            687,
            725,
            738,
            751,
            791,
            830,
            870
        ]
    },
    Thursday: {
        period: [
            "Period 1 in:",
            "Period 2 in:",
            "Recess in:",
            "Period 3 in:",
            "Period 4 in:",
            "Break in:",
            "Period 5 in:",
            "Period 6 in:",
            "Lunch 1 in:",
            "Lunch 2 in:",
            "Period 7 in:",
            "Period 8 in:",
            "End in:"
        ],
        times: [
            518,
            561,
            601,
            621,
            661,
            701,
            706,
            746,
            786,
            806,
            826,
            866,
            906
        ]
    },
    Friday: {
        period: [
            "Period 1 in:",
            "Period 2 in:",
            "Recess in:",
            "Period 3 in:",
            "Period 4 in:",
            "Break in:",
            "Period 5 in:",
            "Period 6 in:",
            "Lunch 1 in:",
            "Lunch 2 in:",
            "Period 7 in:",
            "Period 8 in:",
            "End in:"
        ],
        times: [
            518,
            561,
            601,
            626,
            666,
            706,
            711,
            751,
            791,
            809,
            826,
            866,
            906
        ]
    }
};
