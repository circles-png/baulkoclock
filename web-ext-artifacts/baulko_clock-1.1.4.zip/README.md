# Baulko Clock

By [Angus Mason]("https://github.com/notangoose") 2022.

A bell times extension for Baulkham Hills High School.

Baulko Clock is a popup extension counting down to the next bell for Baulkham Hills High School!
